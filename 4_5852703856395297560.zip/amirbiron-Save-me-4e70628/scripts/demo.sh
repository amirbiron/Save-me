#!/usr/bin/env bash
set -euo pipefail
# File: demo.sh
# Created: 2025-08-10T19:33:14
# Author: ubuntu
# Description: סקריפט דוגמה

main() {
  :
}

main "$@"
