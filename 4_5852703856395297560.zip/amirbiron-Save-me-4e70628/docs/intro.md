---
title: מבוא
date: 2025-08-10
tags: [intro,hebrew]
description: מסמך פתיחה
---

# מבוא

> Created by ubuntu on 2025-08-10T19:32:56

<!-- Summary -->


