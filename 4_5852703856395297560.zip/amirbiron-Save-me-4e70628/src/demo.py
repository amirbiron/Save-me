#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# File: demo.py
# Created: 2025-08-10T19:33:14
# Author: ubuntu
# Description: קובץ דוגמה

from __future__ import annotations


def main() -> None:
    """Entry point."""
    pass


if __name__ == "__main__":
    main()
